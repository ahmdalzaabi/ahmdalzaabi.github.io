# Docs

- message_schema.md: 48-bit event report and bit budget
- fidelity_metric.md: definition of Phi (hit / misid / phantom / miss / abstention)
