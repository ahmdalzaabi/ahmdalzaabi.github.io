# Data (not tracked)

Footage and frames are not committed. Some sources are covered by data-use agreements
(EAD Article 4.5 requires written authorisation before publishing derived data).

Expected layout:
    data/clips/<species>/<clip_id>.mp4
    data/frames/<species>/<clip_id>/*.jpg
    data/labels/          YOLO-format labels
    data/dives/           stitched dive videos + gt.json
