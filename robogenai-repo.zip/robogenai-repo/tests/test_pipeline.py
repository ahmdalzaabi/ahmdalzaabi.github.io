import random
from robogenai.comms import schema, channel
from robogenai.events import trigger
from robogenai.eval import fidelity, synth
from robogenai.comms.schema import Event


def test_roundtrip():
    e = Event(123.4, 140.0, 2, 5, 0.81, depth=12)
    d, ok = schema.decode(schema.encode(e))
    assert ok and d.species == 2 and d.t_start == 123 and d.count in (6,) and d.depth == 13


def test_crc_catches_single_flips():
    m = schema.encode(Event(10, 20, 1, 1, 0.5))
    for b in range(schema.MSG_BITS):
        assert not schema.decode(m ^ (1 << b))[1]


def test_trigger_one_event_per_encounter():
    true, dive = synth.make_dive(seed=1, p_overlap=0)
    fr = synth.simulate_detector(true, dive, 5, perfect=True)
    evs = trigger.detections_to_events(fr, 5)
    assert len(evs) == len(true)


def test_phi_perfect_is_one():
    true, dive = synth.make_dive(seed=2, p_overlap=0)
    assert abs(fidelity.score(true, true)["phi"] - 1) < 1e-9


def test_misid_worse_than_miss():
    true, _ = synth.make_dive(seed=3, p_overlap=0)
    drop = true[1:]
    mis = [Event(e.t_start, e.t_end, (e.species + 1) % 5, e.count, 1) if i == 0 else e for i, e in enumerate(true)]
    assert fidelity.score(true, mis)["phi"] < fidelity.score(true, drop)["phi"]


def test_channel_lossless():
    msgs = [schema.encode(Event(i * 10, i * 10 + 5, i % 5, 2, 0.9)) for i in range(20)]
    rx, st = channel.transmit(msgs)
    assert len(rx) == 20 and st["lost"] == 0
