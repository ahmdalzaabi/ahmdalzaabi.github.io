# RoboGenAI

Event-driven semantic compression for autonomous underwater ecosystem monitoring.
An AUV detects and tracks fish onboard, groups detections into encounter events, and sends each
event as a 48-bit report over the acoustic link instead of raw video. The surface receives a compact
ecological log, scored with an ecological fidelity metric (Phi).

Part of the MARVEL framework (Khalifa University – Dubai Future Foundation).

## Pipeline

    video -> detector + tracker -> event trigger -> 48-bit encoder -> acoustic channel -> decoder -> dive log -> Phi

| Module | Path |
|---|---|
| Detection and tracking (YOLOv8 + ByteTrack) | `src/robogenai/perception/` |
| Event trigger | `src/robogenai/events/trigger.py` |
| Message schema, CRC, channel simulator | `src/robogenai/comms/` |
| Fidelity metric, synthetic dives | `src/robogenai/eval/` |

## Quick start

    pip install -e ".[dev]"
    pytest -q
    python scripts/run_dive.py                 # synthetic dive, three detector conditions
    python scripts/run_dive.py --video data/dives/dive01.mp4 --weights models/best.pt --gt data/dives/dive01.json

## Results so far

- Species identification (LLaVA-1.5-7B, QLoRA): held-out recall rises from 0.31 with one training recording
  to 0.68 with four, then plateaus; no wrong-species substitutions across runs. Rank-4 adapter matches rank 16.
- Bit budget: a two-hour dive fits in under 500 bytes (< 2 % duty cycle at 80 bps).

## Species

Acanthopagrus palmaris, Caranx, Gerres, Chaetodon vagabundus, Epinephelus. Further species
(e.g. coach whipray) are added as detector classes once footage is available.

## Repository layout

    src/robogenai/    library code
    scripts/          entry points
    experiments/      configs and logs for each study
    tests/            unit tests
    docs/             schema, metric definition, notes
    data/ models/     local only, not tracked

## Authors

Ahmed Alzaabi, Khalifa University. Supervisors: Prof. Jorge Dias, Dr. Federico Renda.
