"""48-bit event report: field layout, packing and unpacking.

Layout (MSB first), 48 bits total:
  msg_type      2   0=event, 1=summary, 2=heartbeat, 3=reserved
  t_offset     14   seconds since dive start (max 16383 s = 4.5 h)
  species_id    5   index into the onboard codebook (31 = unknown)
  count_bucket  3   0:1, 1:2, 2:3-4, 3:5-8, 4:9-16, 5:17-32, 6:33-64, 7:>64
  confidence    3   0..7 -> mean confidence in steps of 1/8
  persistence   4   duration bucket, see DUR_EDGES
  depth         5   2 m bins, 0..62 m
  reserved      4
  crc8          8   CRC-8 (poly 0x07) over the first 40 bits

Adjust widths here if your schema doc differs; every other module reads them from FIELDS.
"""
from dataclasses import dataclass

FIELDS = [("msg_type", 2), ("t_offset", 14), ("species_id", 5), ("count_bucket", 3),
          ("confidence", 3), ("persistence", 4), ("depth", 5), ("reserved", 4)]
PAYLOAD_BITS = sum(w for _, w in FIELDS)  # 40
MSG_BITS = PAYLOAD_BITS + 8               # 48

COUNT_EDGES = [1, 2, 4, 8, 16, 32, 64]          # upper bound of buckets 0..6
DUR_EDGES = [1, 2, 3, 5, 8, 12, 18, 25, 35, 50, 70, 100, 140, 200, 300]  # s, buckets 0..14, 15 = longer
COUNT_MID = [1, 2, 3, 6, 12, 24, 48, 80]
DUR_MID = [1, 2, 3, 4, 6.5, 10, 15, 21.5, 30, 42.5, 60, 85, 120, 170, 250, 400]
UNKNOWN = 31


def bucket(x, edges):
    for i, e in enumerate(edges):
        if x <= e:
            return i
    return len(edges)


def crc8(value, nbits, poly=0x07):
    crc = 0
    for i in range(nbits - 1, -1, -1):
        bit = (value >> i) & 1
        top = (crc >> 7) & 1
        crc = ((crc << 1) & 0xFF)
        if top ^ bit:
            crc ^= poly
    return crc


@dataclass
class Event:
    t_start: float          # s
    t_end: float            # s
    species: int            # codebook index
    count: int              # max individuals seen at once
    confidence: float       # mean detector confidence, 0..1
    depth: float = 0.0      # m
    msg_type: int = 0

    @property
    def duration(self):
        return self.t_end - self.t_start


def encode(ev: Event) -> int:
    vals = {
        "msg_type": ev.msg_type,
        "t_offset": min(int(round(ev.t_start)), 2**14 - 1),
        "species_id": ev.species if 0 <= ev.species < UNKNOWN else UNKNOWN,
        "count_bucket": bucket(ev.count, COUNT_EDGES),
        "confidence": min(int(ev.confidence * 8), 7),
        "persistence": bucket(ev.duration, DUR_EDGES),
        "depth": min(int(ev.depth // 2), 31),
        "reserved": 0,
    }
    word = 0
    for name, w in FIELDS:
        v = vals[name]
        assert 0 <= v < 2**w, (name, v)
        word = (word << w) | v
    return (word << 8) | crc8(word, PAYLOAD_BITS)


def decode(msg: int):
    """Return (Event, crc_ok). The event is rebuilt from bucket midpoints."""
    crc = msg & 0xFF
    word = msg >> 8
    ok = crc8(word, PAYLOAD_BITS) == crc
    vals = {}
    shift = PAYLOAD_BITS
    for name, w in FIELDS:
        shift -= w
        vals[name] = (word >> shift) & (2**w - 1)
    t0 = float(vals["t_offset"])
    dur = DUR_MID[vals["persistence"]]
    ev = Event(t_start=t0, t_end=t0 + dur, species=vals["species_id"],
               count=COUNT_MID[vals["count_bucket"]], confidence=(vals["confidence"] + 0.5) / 8,
               depth=vals["depth"] * 2 + 1, msg_type=vals["msg_type"])
    return ev, ok
