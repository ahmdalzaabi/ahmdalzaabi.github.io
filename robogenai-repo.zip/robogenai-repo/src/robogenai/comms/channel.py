"""Acoustic link simulator: bit errors, packet loss, CRC check, optional ARQ."""
import random
from robogenai.comms.schema import MSG_BITS, decode


def transmit(msgs, ber=0.0, p_loss=0.0, max_retx=0, bitrate=80.0, overhead_bits=16, seed=0):
    """Send 48-bit words. Returns (received_events, stats).

    A packet is lost with probability p_loss; otherwise each bit flips with probability ber.
    The receiver drops packets that fail CRC. With max_retx > 0, lost/corrupt packets are resent
    (stop-and-wait ARQ). Airtime counts MSG_BITS + overhead_bits (preamble/sync) per attempt.
    """
    rng = random.Random(seed)
    rx, stats = [], {"sent": 0, "attempts": 0, "lost": 0, "crc_fail": 0, "undetected": 0, "airtime_s": 0.0}
    for m in msgs:
        stats["sent"] += 1
        for attempt in range(max_retx + 1):
            stats["attempts"] += 1
            stats["airtime_s"] += (MSG_BITS + overhead_bits) / bitrate
            if rng.random() < p_loss:
                stats["lost"] += 1
                continue
            r = m
            for b in range(MSG_BITS):
                if rng.random() < ber:
                    r ^= 1 << b
            ev, ok = decode(r)
            if not ok:
                stats["crc_fail"] += 1
                continue
            if r != m:
                stats["undetected"] += 1
            rx.append(ev)
            break
    return rx, stats
