"""Run a trained YOLOv8 model with ByteTrack on a video and return per-frame detections
in the format expected by trigger.detections_to_events: [(species, conf, track_id), ...].

Usage:
    frames, fps = frames_from_video("dive.mp4", "best.pt", class_map={0: 0, 1: 1, ...})
"""

def frames_from_video(video, weights, class_map=None, conf=0.25, imgsz=640, vid_stride=1):
    from ultralytics import YOLO
    import cv2
    fps = cv2.VideoCapture(video).get(cv2.CAP_PROP_FPS) / vid_stride
    model = YOLO(weights)
    frames = []
    for r in model.track(source=video, stream=True, persist=True, tracker="bytetrack.yaml",
                         conf=conf, imgsz=imgsz, vid_stride=vid_stride, verbose=False):
        dets = []
        b = r.boxes
        if b is not None and len(b):
            ids = b.id.int().tolist() if b.id is not None else [None] * len(b)
            for c, p, t in zip(b.cls.int().tolist(), b.conf.tolist(), ids):
                dets.append((class_map.get(c, c) if class_map else c, float(p), t))
        frames.append(dets)
    return frames, fps


def stitch_dive(clips, out="dive.mp4", gap_s=(60, 300), fps=None, seed=0, size=None):
    """Concatenate real clips with empty-water gap frames (mean colour of the previous clip's
    first frame, plus noise) and return ground-truth (clip, t_start, t_end) for each clip."""
    import cv2, random, numpy as np
    rng = random.Random(seed)
    caps = [cv2.VideoCapture(c) for c in clips]
    fps = fps or caps[0].get(cv2.CAP_PROP_FPS)
    w = int(caps[0].get(cv2.CAP_PROP_FRAME_WIDTH)); h = int(caps[0].get(cv2.CAP_PROP_FRAME_HEIGHT))
    if size: w, h = size
    vw = cv2.VideoWriter(out, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    t, gt = 0, []
    for clip, cap in zip(clips, caps):
        ok, fr = cap.read()
        bg = cv2.resize(fr, (w, h)).mean(axis=(0, 1)) if ok else np.array([90, 60, 20])
        for _ in range(int(rng.uniform(*gap_s) * fps)):
            noise = np.random.normal(0, 4, (h, w, 3))
            vw.write(np.clip(bg + noise, 0, 255).astype("uint8")); t += 1
        start = t
        while ok:
            vw.write(cv2.resize(fr, (w, h))); t += 1
            ok, fr = cap.read()
        gt.append((clip, start / fps, t / fps))
    vw.release()
    return gt
