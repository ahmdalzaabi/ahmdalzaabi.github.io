"""Turn per-frame detections into encounter events (one state machine per species).

Input: list of frames; each frame is a list of (species, confidence, track_id or None).
Open an event when >= n_open of the last m_window frames contain the species above conf_min.
Close it after k_close consecutive frames without it. Count = max distinct tracks in one frame
(or max detections per frame when no tracker is used).
"""
from collections import deque, defaultdict
from robogenai.comms.schema import Event


def detections_to_events(frames, fps, conf_min=0.4, n_open=3, m_window=5, k_close=15,
                         min_dur=0.5, depth=0.0):
    hist = defaultdict(lambda: deque(maxlen=m_window))
    open_ev = {}     # species -> dict
    miss = defaultdict(int)
    events = []
    species_all = {s for f in frames for (s, c, _) in f}
    for i, dets in enumerate(frames):
        present = defaultdict(list)
        for s, c, tid in dets:
            if c >= conf_min:
                present[s].append((c, tid))
        for s in species_all:
            hist[s].append(s in present)
            if s in open_ev:
                e = open_ev[s]
                if s in present:
                    miss[s] = 0
                    e["last"] = i
                    e["confs"] += [c for c, _ in present[s]]
                    ids = {t for _, t in present[s] if t is not None}
                    e["count"] = max(e["count"], len(ids) if ids else len(present[s]))
                    e["tracks"] |= ids
                else:
                    miss[s] += 1
                    if miss[s] >= k_close:
                        events.append(_close(e, s, fps, depth))
                        del open_ev[s]
            elif sum(hist[s]) >= n_open and s in present:
                start = i - len(hist[s]) + 1 + next(j for j, v in enumerate(hist[s]) if v)
                ids = {t for _, t in present[s] if t is not None}
                open_ev[s] = {"first": start, "last": i, "confs": [c for c, _ in present[s]],
                              "count": len(ids) if ids else len(present[s]), "tracks": set(ids)}
                miss[s] = 0
    for s, e in open_ev.items():
        events.append(_close(e, s, fps, depth))
    events = [e for e in events if e.duration >= min_dur]
    return sorted(events, key=lambda e: e.t_start)


def _close(e, s, fps, depth):
    conf = sum(e["confs"]) / len(e["confs"])
    return Event(t_start=e["first"] / fps, t_end=(e["last"] + 1) / fps, species=s,
                 count=max(e["count"], 1), confidence=conf, depth=depth)
