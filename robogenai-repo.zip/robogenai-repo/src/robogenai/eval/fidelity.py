"""Ecological fidelity Phi (v1 structure): match by temporal IoU, then judge the label.

Phi = (0.5*F1 + 0.3*abundance + 0.2*timing) * P_err
P_err = max(0, 1 - (lam_misid*misid + phantom) / max(n_true, 1))
NOTE: replace this file with your own fidelity.py if its P_err differs; the interface is score(true, rep).
"""
import math
from robogenai.comms.schema import UNKNOWN


def tiou(a, b):
    inter = max(0.0, min(a.t_end, b.t_end) - max(a.t_start, b.t_start))
    union = max(a.t_end, b.t_end) - min(a.t_start, b.t_start)
    return inter / union if union > 0 else 0.0


def score(true, rep, iou_min=0.1, lam_misid=2.0):
    pairs = sorted(((tiou(t, r), i, j) for i, t in enumerate(true) for j, r in enumerate(rep)), reverse=True)
    mt, mr, matches = set(), set(), []
    for iou, i, j in pairs:
        if iou < iou_min:
            break
        if i in mt or j in mr:
            continue
        mt.add(i); mr.add(j); matches.append((i, j, iou))
    hits = [(i, j, iou) for i, j, iou in matches if rep[j].species == true[i].species]
    misid = sum(1 for i, j, _ in matches if rep[j].species not in (true[i].species, UNKNOWN))
    abst = sum(1 for i, j, _ in matches if rep[j].species == UNKNOWN)
    phantom = len(rep) - len(mr)
    miss = len(true) - len(mt)
    n_rep = len(rep) - abst
    prec = len(hits) / n_rep if n_rep else 0.0
    rec = len(hits) / len(true) if true else 0.0
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
    ab = [max(0.0, 1 - abs(math.log2(rep[j].count / true[i].count)) / 3) for i, j, _ in hits]
    abundance = sum(ab) / len(ab) if ab else 0.0
    timing = sum(iou for _, _, iou in hits) / len(hits) if hits else 0.0
    p_err = max(0.0, 1 - (lam_misid * misid + phantom) / max(len(true), 1))
    phi = (0.5 * f1 + 0.3 * abundance + 0.2 * timing) * p_err
    return {"phi": phi, "f1": f1, "precision": prec, "recall": rec, "abundance": abundance,
            "timing": timing, "p_err": p_err, "hits": len(hits), "misid": misid,
            "phantom": phantom, "miss": miss, "abstain": abst, "n_true": len(true), "n_rep": len(rep)}
