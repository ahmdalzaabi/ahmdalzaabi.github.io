"""Synthetic dive: ground-truth encounters with empty gaps, plus a simulated detector.

Lets the whole pipeline run before real continuous footage exists. Replace the simulated
detector with yolo_adapter.frames_from_video() on a stitched dive video for the real run.
"""
import random
from robogenai.comms.schema import Event

SPECIES = ["acanthopagrus_palmaris", "caranx", "gerres", "chaetodon_vagabundus", "epinephelus"]
# encounter counts per species, matching the clip inventory (AP 7, caranx 3, gerres 2, 1, 1)
DEFAULT_MIX = {0: 7, 1: 3, 2: 2, 3: 1, 4: 1}


def make_dive(mix=DEFAULT_MIX, dive_s=7200, dur=(6, 45), gap=(60, 600), counts=(1, 6),
              p_overlap=0.15, seed=0):
    rng = random.Random(seed)
    order = [s for s, n in mix.items() for _ in range(n)]
    rng.shuffle(order)
    t, evs = rng.uniform(*gap) / 2, []
    for s in order:
        d = rng.uniform(*dur)
        evs.append(Event(t, t + d, s, rng.randint(*counts), 1.0))
        if rng.random() < p_overlap:  # second species in the same scene (like clips 9892/9908)
            s2 = rng.choice([x for x in mix if x != s])
            o = rng.uniform(0.2, 0.6) * d
            evs.append(Event(t + o, t + o + rng.uniform(0.5, 1.0) * d, s2, rng.randint(1, 3), 1.0))
        t += d + rng.uniform(*gap)
    scale = min(1.0, (dive_s - 60) / t)
    for e in evs:
        e.t_start *= scale; e.t_end *= scale
    return sorted(evs, key=lambda e: e.t_start), dive_s


def simulate_detector(true, dive_s, fps=5, p_det=0.8, p_misid=0.03, fp_rate=0.002,
                      conf=(0.75, 0.1), seed=0, perfect=False, n_species=5):
    """Per-frame detections with track ids. fp_rate = false detections per empty frame."""
    rng = random.Random(seed)
    n = int(dive_s * fps)
    frames = [[] for _ in range(n)]
    tid = 0
    for e in true:
        ids = list(range(tid, tid + e.count)); tid += e.count
        for f in range(int(e.t_start * fps), min(n, int(e.t_end * fps))):
            for k in ids:
                if perfect:
                    frames[f].append((e.species, 1.0, k)); continue
                if rng.random() < p_det:
                    s = e.species if rng.random() > p_misid else rng.randrange(n_species)
                    c = min(1.0, max(0.0, rng.gauss(*conf)))
                    frames[f].append((s, c, k))
    if not perfect:
        for f in range(n):
            if rng.random() < fp_rate:
                frames[f].append((rng.randrange(n_species), rng.uniform(0.3, 0.7), None))
    return frames
