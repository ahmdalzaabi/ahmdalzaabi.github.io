"""End-to-end: detections -> events -> 48-bit messages -> acoustic channel -> decoded log -> Phi.

  python run_dive.py                      # synthetic dive, three detector conditions
  python run_dive.py --video dive.mp4 --weights best.pt --gt gt.json   # real stitched dive
"""
import argparse, json
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from robogenai.eval import synth, fidelity
from robogenai.events import trigger
from robogenai.comms import schema, channel
from robogenai.comms.schema import Event


def run(frames, fps, true, ber=1e-3, p_loss=0.1, max_retx=1, bitrate=80, seed=0, trig=None):
    evs = trigger.detections_to_events(frames, fps, **(trig or {}))
    msgs = [schema.encode(e) for e in evs]
    rx, st = channel.transmit(msgs, ber=ber, p_loss=p_loss, max_retx=max_retx, bitrate=bitrate, seed=seed)
    return evs, rx, st, fidelity.score(true, evs), fidelity.score(true, rx)


def plot_timeline(true, onboard, rx, path, names):
    fig, ax = plt.subplots(figsize=(11, 3.2))
    rows = [("ground truth", true, "#444"), ("onboard events", onboard, "#1f77b4"), ("decoded at surface", rx, "#d62728")]
    for y, (lab, evs, col) in enumerate(rows):
        for e in evs:
            ax.broken_barh([(e.t_start / 60, max(e.duration, 3) / 60)], (y - 0.35, 0.7), color=col, alpha=0.85)
            ax.text(e.t_start / 60, y + 0.42, f"{names.get(e.species, '?')[:4]}×{e.count}", fontsize=6, rotation=35)
    ax.set_yticks(range(3)); ax.set_yticklabels([r[0] for r in rows]); ax.invert_yaxis()
    ax.set_xlabel("dive time (min)"); ax.set_ylim(2.8, -0.9); ax.grid(axis="x", alpha=0.3)
    fig.tight_layout(); fig.savefig(path, dpi=160); plt.close(fig)


def fmt(s):
    return (f"Phi={s['phi']:.3f}  F1={s['f1']:.2f}  abund={s['abundance']:.2f}  timing={s['timing']:.2f}  "
            f"hit={s['hits']} misid={s['misid']} phantom={s['phantom']} miss={s['miss']}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--video"); ap.add_argument("--weights"); ap.add_argument("--gt")
    ap.add_argument("--fps", type=float, default=5); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--p_loss", type=float, default=0.1); ap.add_argument("--ber", type=float, default=1e-3)
    a = ap.parse_args()
    names = dict(enumerate(synth.SPECIES)); names[schema.UNKNOWN] = "unknown"
    if a.video:
        from robogenai.perception.yolo_adapter import frames_from_video
        frames, fps = frames_from_video(a.video, a.weights)
        true = [Event(**e) for e in json.load(open(a.gt))]
        conds = {"yolo+bytetrack": frames}
    else:
        true, dive_s = synth.make_dive(seed=a.seed)
        fps = a.fps
        conds = {
            "perfect detector": synth.simulate_detector(true, dive_s, fps, perfect=True),
            "good detector (p_det .8)": synth.simulate_detector(true, dive_s, fps, seed=a.seed),
            "weak detector (p_det .5, fp x5)": synth.simulate_detector(true, dive_s, fps, p_det=0.5, p_misid=0.08, fp_rate=0.01, seed=a.seed),
        }
    print(f"ground truth: {len(true)} encounters")
    for k, fr in conds.items():
        evs, rx, st, s_on, s_rx = run(fr, fps, true, ber=a.ber, p_loss=a.p_loss, seed=a.seed)
        print(f"\n[{k}]  {len(evs)} events, {len(evs)*schema.MSG_BITS//8} bytes payload, airtime {st['airtime_s']:.1f} s")
        print("  onboard :", fmt(s_on))
        print("  surface :", fmt(s_rx), f"| lost={st['lost']} crc_fail={st['crc_fail']}")
    plot_timeline(true, evs, rx, "results/timeline.png", names)
    print("\nsaved results/timeline.png")
